package homework2;

public class Q4 {
    public static void main(String[] args) {
        
    }
}
